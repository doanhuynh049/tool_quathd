GLSLCOMPILER_README_E

1. Preface
 This CD-R includes the GLSL off-line compiler of R8A7796 GX6250 OpenGL ES Library
 for Linux. You may only use these tools by agreeing to the SDK licensing terms of
 Imagination Technologies Limited.

 URL for SDK licensing:
 https://developer.imaginationtech.com/terms/powervr-tools-software-eula/

2. Specification for GL_IMG_shader_binary
 Refer to the GL_IMG_shader_binary in following URL.
 URL in Khronos site: http://www.khronos.org/registry/gles/

3. Usage
 Run the GLSLCompilerFrontendDDK_host with following syntax from command prompt on Linux machine.
 (Please store the glslcompilerfrontend_host and the libglslcompiler.4.45.2.58.so in the same folder)

 -
    Syntax: GLSLCompilerFrontendDDK_host <sourcefile> <outputfile> <-v,-f> -bvnc 4.45.2.58 [OPTIONS]

    Use
            -v for vertex shaders or
            -f for fragment shaders.

    OPTIONS are: -nowarn                 : disable compiler warnings
                 -validateonly           : only validate the code. Do not compile
                 -notcomplete            : don't check for code completeness
 -

GLSLCOMPILER_README_E.TXT / Feb 2024
